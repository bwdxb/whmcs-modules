CREATE TABLE `tbl_buzinessware_orders` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `ServiceId` int(11) NOT NULL,
  `OrderId` int(11) NOT NULL,
  `BwServiceId` int(11) NOT NULL,
  `BwDomainids` int(11) NOT NULL,
  `Invoiceid` int(11) NOT NULL,
  `OrderDate` int(11) NOT NULL,
  PRIMARY KEY (`Id`),
  KEY `idx_bw_order_service` (`ServiceId`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=latin1;